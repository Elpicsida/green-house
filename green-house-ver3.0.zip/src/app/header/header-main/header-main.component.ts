import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'header-main',
  templateUrl: './header-main.component.html',
  styleUrls: ['./header-main.component.scss']
})
export class HeaderMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
