import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'content-main',
  templateUrl: './content-main.component.html',
  styleUrls: ['./content-main.component.scss']
})
export class ContentMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
