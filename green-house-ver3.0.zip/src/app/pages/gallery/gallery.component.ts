import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gallery-page',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})
export class GalleryPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
