import { LinkModel } from "./link.model";

export class FooterItem {
    public Title: String;
    public Links: LinkModel[];
}