export class LinkModel {
    public Label: String;
    public Url?: String;
    public IconName?: String;
}